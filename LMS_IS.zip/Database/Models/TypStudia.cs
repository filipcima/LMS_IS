﻿using System;

namespace LMSIS.Database.Models
{
    public class TypStudia
    {
        public int IdTypStudia { get; set; }
        public string Nazev { get; set; }
    }
}