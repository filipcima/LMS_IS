﻿using System;

namespace LMSIS.Database.Models
{
    public class Obor
    {
        public int IdObor { get; set; }
        public string Nazev { get; set; }
        public string Popis { get; set; }
    }
}